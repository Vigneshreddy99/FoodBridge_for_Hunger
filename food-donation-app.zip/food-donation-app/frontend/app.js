const API = "http://localhost:3000/api";
let token = localStorage.getItem("token");
let currentUser = JSON.parse(localStorage.getItem("user") || "null");

// -- AUTH --
function fillCreds(email, pass) {
  document.getElementById("loginEmail").value = email;
  document.getElementById("loginPassword").value = pass;
}

document.getElementById("togglePass").addEventListener("click", () => {
  const p = document.getElementById("loginPassword");
  p.type = p.type === "password" ? "text" : "password";
});

document.getElementById("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = document.getElementById("loginBtn");
  const err = document.getElementById("loginError");
  btn.textContent = "Signing in..."; btn.disabled = true;
  try {
    const res = await fetch(`${API}/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: document.getElementById("loginEmail").value, password: document.getElementById("loginPassword").value })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    token = data.token;
    currentUser = data.user;
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(currentUser));
    showDashboard();
  } catch(e) { err.textContent = e.message; }
  btn.textContent = "Sign In"; btn.disabled = false;
});

function showDashboard() {
  document.getElementById("loginPage").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  document.getElementById("sidebarName").textContent = currentUser.name;
  document.getElementById("topbarName").textContent = currentUser.name;
  document.getElementById("avatarInitial").textContent = currentUser.name[0].toUpperCase();
  const rb = document.getElementById("sidebarRole");
  rb.textContent = currentUser.role.toUpperCase();
  rb.className = "role-badge";
  loadOverview();
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.clear(); token = null; currentUser = null;
  document.getElementById("dashboard").classList.add("hidden");
  document.getElementById("loginPage").classList.remove("hidden");
});

// -- NAV --
const sectionTitles = { overview: "Overview", donate: "Post Donation", browse: "Browse Donations", requests: "Requests" };
document.querySelectorAll(".nav-item").forEach(item => {
  item.addEventListener("click", e => {
    e.preventDefault();
    document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
    document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
    item.classList.add("active");
    const sec = item.dataset.section;
    document.getElementById(sec).classList.add("active");
    document.getElementById("sectionTitle").textContent = sectionTitles[sec];
    if (sec === "browse") loadDonations();
    if (sec === "requests") loadRequests();
    if (sec === "overview") loadOverview();
  });
});

// -- HELPERS --
function authHeaders() { return { "Content-Type": "application/json", "Authorization": `Bearer ${token}` }; }
function esc(s) { return String(s||"").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

// -- OVERVIEW --
async function loadOverview() {
  try {
    const [dRes, rRes] = await Promise.all([
      fetch(`${API}/donations`, { headers: authHeaders() }),
      fetch(`${API}/requests`, { headers: authHeaders() })
    ]);
    const donations = await dRes.json();
    const requests = await rRes.json();
    document.getElementById("statTotal").textContent = donations.length;
    document.getElementById("statAvailable").textContent = donations.filter(d => d.status === "available").length;
    document.getElementById("statClaimed").textContent = donations.filter(d => d.status === "claimed").length;
    document.getElementById("statRequests").textContent = requests.filter(r => r.status === "pending").length;
    const recent = donations.slice(-5).reverse();
    document.getElementById("recentList").innerHTML = recent.length
      ? recent.map(d => `<div class="card" style="margin-bottom:0.75rem">
          <h3>${esc(d.foodDescription)}</h3>
          <p>By ${esc(d.donorName)} &bull; ${esc(d.location.address)}</p>
          <div class="card-footer"><span class="badge ${d.status}">${d.status}</span><small>${new Date(d.createdAt).toLocaleDateString()}</small></div>
        </div>`).join("")
      : "<p style='color:#6b7280'>No donations yet.</p>";
  } catch(e) { console.error(e); }
}

// -- DONATE --
document.getElementById("detectLocation").addEventListener("click", () => {
  if (!navigator.geolocation) return alert("Geolocation not supported");
  navigator.geolocation.getCurrentPosition(pos => {
    document.querySelector("[name=lat]").value = pos.coords.latitude.toFixed(6);
    document.querySelector("[name=lng]").value = pos.coords.longitude.toFixed(6);
  });
});

document.getElementById("donateForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = e.target, msg = document.getElementById("donateMsg");
  try {
    const res = await fetch(`${API}/donations`, {
      method: "POST", headers: authHeaders(),
      body: JSON.stringify({
        donorName: f.donorName.value, foodDescription: f.foodDescription.value,
        quantity: f.quantity.value, expiryDate: f.expiryDate.value || null,
        location: { address: f.address.value, lat: parseFloat(f.lat.value), lng: parseFloat(f.lng.value) }
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    msg.className = "msg"; msg.textContent = `Donation posted! ID: ${data.id}`;
    f.reset();
  } catch(err) { msg.className = "msg error"; msg.textContent = err.message; }
});

// -- BROWSE --
async function loadDonations(params = "") {
  const list = document.getElementById("donationList");
  list.innerHTML = "<p>Loading...</p>";
  try {
    const data = await fetch(`${API}/donations${params}`, { headers: authHeaders() }).then(r => r.json());
    if (!data.length) { list.innerHTML = "<p style='color:#6b7280'>No donations found.</p>"; return; }
    list.innerHTML = data.map(d => `
      <div class="card">
        <h3>${esc(d.foodDescription)}</h3>
        <p>?? ${esc(d.donorName)}</p>
        <p>?? ${esc(d.quantity)}</p>
        <p>?? ${esc(d.location.address)}</p>
        ${d.expiryDate ? `<p>? Expires: ${d.expiryDate}</p>` : ""}
        <div class="card-footer">
          <span class="badge ${d.status}">${d.status}</span>
          <small>ID: ${d.id}</small>
        </div>
      </div>`).join("");
  } catch { list.innerHTML = "<p class='msg error'>Failed to load.</p>"; }
}

document.getElementById("loadAllBtn").addEventListener("click", () => loadDonations());
document.getElementById("filterBtn").addEventListener("click", () => {
  const lat = document.getElementById("filterLat").value;
  const lng = document.getElementById("filterLng").value;
  const radius = document.getElementById("filterRadius").value;
  if (!lat || !lng) return alert("Enter latitude and longitude.");
  loadDonations(`?lat=${lat}&lng=${lng}&radius=${radius}`);
});

// -- REQUESTS --
document.getElementById("requestForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = e.target, msg = document.getElementById("requestMsg");
  try {
    const res = await fetch(`${API}/requests`, {
      method: "POST", headers: authHeaders(),
      body: JSON.stringify({ ngoName: f.ngoName.value, donationId: parseInt(f.donationId.value), message: f.message.value })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    msg.className = "msg"; msg.textContent = `Request sent! ID: ${data.id}`;
    f.reset(); loadRequests();
  } catch(err) { msg.className = "msg error"; msg.textContent = err.message; }
});

async function loadRequests() {
  const list = document.getElementById("requestList");
  list.innerHTML = "<p>Loading...</p>";
  try {
    const data = await fetch(`${API}/requests`, { headers: authHeaders() }).then(r => r.json());
    if (!data.length) { list.innerHTML = "<p style='color:#6b7280'>No requests yet.</p>"; return; }
    list.innerHTML = data.map(r => `
      <div class="card">
        <h3>${esc(r.ngoName)}</h3>
        <p>Donation ID: ${r.donationId}</p>
        ${r.message ? `<p>?? ${esc(r.message)}</p>` : ""}
        <div class="card-footer">
          <span class="badge ${r.status}">${r.status}</span>
          <small>${new Date(r.createdAt).toLocaleDateString()}</small>
        </div>
      </div>`).join("");
  } catch { list.innerHTML = "<p class='msg error'>Failed to load.</p>"; }
}

// -- INIT --
if (token && currentUser) showDashboard();
