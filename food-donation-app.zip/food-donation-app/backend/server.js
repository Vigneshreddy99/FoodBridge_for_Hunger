const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const { router: authRouter, SECRET } = require("./routes/auth");
const donationRoutes = require("./routes/donations");
const requestRoutes = require("./routes/requests");

const app = express();
app.use(cors());
app.use(express.json());

// Auth middleware
function authenticate(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "Unauthorized" });
  try {
    req.user = jwt.verify(auth.split(" ")[1], SECRET);
    next();
  } catch { res.status(401).json({ error: "Invalid token" }); }
}

app.use("/api/auth", authRouter);
app.use("/api/donations", authenticate, donationRoutes);
app.use("/api/requests", authenticate, requestRoutes);

app.get("/", (req, res) => res.json({ message: "Food Donation API" }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
