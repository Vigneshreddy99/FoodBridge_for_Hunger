const express = require("express");
const router = express.Router();

const requests = [];
let nextId = 1;

router.post("/", (req, res) => {
  const { ngoName, donationId, message } = req.body;
  if (!ngoName || !donationId)
    return res.status(400).json({ error: "ngoName and donationId are required" });
  const request = {
    id: nextId++, ngoName,
    donationId: parseInt(donationId),
    message: message || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  requests.push(request);
  res.status(201).json(request);
});

router.get("/", (req, res) => {
  const { donationId } = req.query;
  res.json(donationId ? requests.filter(r => r.donationId === parseInt(donationId)) : requests);
});

router.patch("/:id/status", (req, res) => {
  const request = requests.find(r => r.id === parseInt(req.params.id));
  if (!request) return res.status(404).json({ error: "Not found" });
  const { status } = req.body;
  if (!["pending","approved","rejected"].includes(status))
    return res.status(400).json({ error: "Invalid status" });
  request.status = status;
  res.json(request);
});

module.exports = router;
