const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const router = express.Router();

const SECRET = "food_donation_secret_2026";

// Hardcoded users (swap with DB in production)
const users = [
  { id: 1, name: "Rahul Sharma",   email: "donor@food.com",  password: bcrypt.hashSync("Donor@123",  10), role: "donor" },
  { id: 2, name: "GreenHope NGO",  email: "ngo@food.com",    password: bcrypt.hashSync("Ngo@123",    10), role: "ngo"   },
  { id: 3, name: "Admin",          email: "admin@food.com",  password: bcrypt.hashSync("Admin@123",  10), role: "admin" },
];

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: "Invalid email or password" });
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, SECRET, { expiresIn: "8h" });
  res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
});

router.get("/me", (req, res) => {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "No token" });
  try {
    const decoded = jwt.verify(auth.split(" ")[1], SECRET);
    res.json(decoded);
  } catch { res.status(401).json({ error: "Invalid token" }); }
});

module.exports = { router, SECRET };
