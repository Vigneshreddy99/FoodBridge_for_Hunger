const express = require("express");
const router = express.Router();

const donations = [];
let nextId = 1;

router.post("/", (req, res) => {
  const { donorName, foodDescription, quantity, expiryDate, location } = req.body;
  if (!donorName || !foodDescription || !location)
    return res.status(400).json({ error: "donorName, foodDescription, and location are required" });
  const donation = {
    id: nextId++, donorName, foodDescription,
    quantity: quantity || "unspecified",
    expiryDate: expiryDate || null,
    location, status: "available",
    createdAt: new Date().toISOString(),
  };
  donations.push(donation);
  res.status(201).json(donation);
});

router.get("/", (req, res) => {
  const { lat, lng, radius } = req.query;
  let results = donations.filter(d => d.status === "available");
  if (lat && lng && radius) {
    const [uLat, uLng, maxKm] = [parseFloat(lat), parseFloat(lng), parseFloat(radius)];
    results = results.filter(d => haversine(uLat, uLng, d.location.lat, d.location.lng) <= maxKm);
  }
  res.json(results);
});

router.patch("/:id/status", (req, res) => {
  const donation = donations.find(d => d.id === parseInt(req.params.id));
  if (!donation) return res.status(404).json({ error: "Not found" });
  const { status } = req.body;
  if (!["available","claimed","expired"].includes(status))
    return res.status(400).json({ error: "Invalid status" });
  donation.status = status;
  res.json(donation);
});

function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371, toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

module.exports = router;
